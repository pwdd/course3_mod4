require 'test_helper'

class RaceRefTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
